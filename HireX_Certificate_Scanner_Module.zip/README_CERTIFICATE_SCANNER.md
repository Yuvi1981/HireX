# 🛡️ HireX: Certificate Scanner & Skill Verification Subsystem

The **Certificate Scanner & Skill Verification Subsystem** is an institutional-grade, AI-powered forensic document auditing and multi-signal competency verification engine.

---

## 🌟 Key Features

### 1. Forensic Certificate Scanner (`CertificateScannerWorkspace.tsx` & `certificate_scanner.py`)
- **Multi-Provider OCR Parsing**:
  - Microsoft Certifications (Azure AI-102, AZ-900, DP-100, SC-900, PL-300).
  - AWS Certifications (Solutions Architect, Developer, Cloud Practitioner).
  - NPTEL / SWAYAM National Certifications with Elite / Gold / Silver badges.
  - Coursera & Stanford/DeepLearning.AI credentials.
- **Cryptographic Fraud Prevention**:
  - **SHA-256 Collision Check**: Detects duplicate certificates uploaded by multiple candidates.
  - **Levenshtein Distance KYC Name Audit**: Catches certificate theft or mismatched names (e.g. certificate belonging to another student).
  - **Expiration & Tamper Auditing**: Flags expired or backdated credentials with security warnings.
- **Academic Credit Mapping (NCrF / AICTE)**:
  - Assigns National Credit Framework (NCrF) academic credits (1 to 4 credits).
  - Computes institutional verified score boosts (+2 to +5 points).
  - Automatically updates student profile skills with "Verified" badge status upon commit.

### 2. Multi-Signal Skill Verification Engine (`skill_verifier.py` & `SkillVerificationView.tsx`)
- **Ridge-Regression Calibration Model**:
  - Combines 4 signals: (1) Proctored Assessment Score, (2) Code Complexity AST, (3) GitHub Proof-of-Work, (4) Academic Benchmarks.
  - Outputs a calibrated 0-100 verified score and badge tier (`Gold - Industry Ready`, `Silver - Proficient`, `Bronze - Competent`).
- **AI Webcam Proctoring**:
  - Built-in TinyFaceDetector deep-learning face-tracking with fallback calibrated CV.
  - Multi-face and no-face detection, audio anomaly monitor, and fullscreen lock.

### 3. Tamper-Evident Verified Skill Passport (`VerifiedSkillPassport.tsx`)
- Digital skill credential passport displaying verified competency badges.
- Career pathway alignment and skill level progression history.
- Shareable institutional verification link with cryptographic signature.

---

## 📦 What Is Included

### Backend (`server/`)
- `server/app/services/certificate_scanner.py`: Forensic parser, OCR anchor extraction, SHA-256 duplicate cache, Levenshtein KYC auditor, NCrF credit assigner.
- `server/app/ml/skill_verifier.py`: Ridge regression calibration model (multi-signal proof-of-work -> verified badge).
- `server/app/ml/skill_extractor.py`: Semantic skill extractor from resumes and documents.
- `server/app/ml/skill_intelligence.py`: Skill embeddings and semantic distance mapping.
- `server/app/services/skill_ontology.py`: Standardized skill taxonomy.
- `server/app/services/jd_skill_analysis.py`: Job description skill parser and alignment.
- `server/tests/test_certificate_scanner.py`: Unit tests for certificate parsing, KYC name mismatch, duplicate SHA-256 detection, and skill assignment.
- `server/tests/test_jd_skill_analysis.py`: Unit tests for JD skill matching.

### Frontend (`client/`)
- `client/src/components/certificates/CertificateScannerWorkspace.tsx`: Complete OCR scanner UI with preset samples, upload drag-and-drop, forensic audit cards, skill badges, and profile commit button.
- `client/src/views/SkillVerificationView.tsx`: Comprehensive proctored assessment and skill verification view.
- `client/src/components/passport/VerifiedSkillPassport.tsx`: Verified Skill Passport UI card with career pathways.
- `client/src/components/modals/CertificateScannerModal.tsx`: Slide-over modal for quick certificate upload.
- `client/src/components/modals/CandidatePassportModal.tsx`: Institutional passport view for recruiters and TPOs.
- `client/src/components/RoleSpecificSkillAnalysis.tsx`: Dynamic competency gap radar.
- `client/src/data/skillQuestions.ts`: Multi-category technical assessment questions.
- `client/src/services/jdSkillAnalysis.ts`: Frontend JD semantic matching bridge.
- `client/src/services/faceDetection.ts`: Dynamic face-api AI detection and proctoring service.

---

## 🚀 Quick Installation
1. Extract `certificate_scanner_and_skill_verification.zip` into your project root.
2. Run the automated installer:
   ```bash
   python apply_certificate_patch.py
   ```
3. Run the automated test suite:
   ```bash
   python -m unittest server/tests/test_certificate_scanner.py
   ```
