#!/usr/bin/env python3
"""
HireX Certificate Scanner & Skill Verification Intelligent Drop-in Installer.
Installs and integrates the Certificate Scanner & Skill Verification module into any target HireX installation:
- Automatically detects project root directory.
- Copies all backend services, ML verifiers, unit test suites, and frontend components.
- Validates the test suite to verify 100% test integrity.
"""

import os
import sys
import shutil
import subprocess

def log(msg):
    print(f"[HireX Certificate Scanner Installer] {msg}")

def find_project_root():
    cwd = os.path.abspath(os.getcwd())
    if os.path.exists(os.path.join(cwd, "server")) and os.path.exists(os.path.join(cwd, "client")):
        return cwd
    script_dir = os.path.abspath(os.path.dirname(__file__))
    if os.path.exists(os.path.join(script_dir, "server")) and os.path.exists(os.path.join(script_dir, "client")):
        return script_dir
    parent = os.path.dirname(script_dir)
    if os.path.exists(os.path.join(parent, "server")) and os.path.exists(os.path.join(parent, "client")):
        return parent
    return None

def main():
    root_dir = find_project_root()
    if not root_dir:
        print("[ERROR] Could not locate HireX project root directory (containing 'server' and 'client').")
        sys.exit(1)

    log(f"Target HireX root: {root_dir}")
    source_dir = os.path.abspath(os.path.dirname(__file__))

    # 1. Copy Files
    for root, dirs, files in os.walk(source_dir):
        for f in files:
            if f in ["apply_certificate_patch.py", "README_CERTIFICATE_SCANNER.md"]:
                continue
            src_full = os.path.join(root, f)
            rel = os.path.relpath(src_full, source_dir)
            dst_full = os.path.join(root_dir, rel)
            os.makedirs(os.path.dirname(dst_full), exist_ok=True)
            shutil.copy2(src_full, dst_full)
            log(f"Installed: {rel}")

    # 2. Run validation tests
    log("Running automated validation test suite...")
    env = os.environ.copy()
    env["PYTHONPATH"] = os.path.join(root_dir, "server")
    try:
        res = subprocess.run(
            [sys.executable, "-m", "unittest", "server/tests/test_certificate_scanner.py"],
            cwd=root_dir,
            env=env,
            capture_output=True,
            text=True
        )
        if res.returncode == 0:
            log("SUCCESS! Certificate Scanner test cases PASSED!")
        else:
            log(f"Unittest output:\n{res.stdout}\n{res.stderr}")
    except Exception as e:
        log(f"Note: Could not automatically invoke unittest: {e}")

    log("Certificate Scanner & Skill Verification installation complete!")

if __name__ == "__main__":
    main()
