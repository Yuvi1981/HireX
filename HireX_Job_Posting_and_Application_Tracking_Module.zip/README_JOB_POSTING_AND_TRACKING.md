# 💼 HireX: Job Opportunity Posting & 6-Stage Application Tracking System

This subsystem establishes a closed-loop connection between corporate recruiters posting verified placement opportunities and students applying and tracking their candidacy across all hiring stages.

---

## 🌟 Key Features

### 1. Recruiter Opportunity Creation (`RecruiterPortalView.tsx` & `server/app/routes/recruiter.py`)
- Corporate recruiters post verified job opportunities (Title, Company, CTC, Location, Domain, Required Skills, Expiration Date).
- Opportunities are immediately persisted into `canonical_store.json` and broadcast to students in real-time.

### 2. Student Persistent Application State (`OpportunitiesView.tsx` & `OpportunityModal.tsx`)
- Students discover opportunities with AI match percentage algorithms.
- **Persistent Applied Lock**: When a student clicks Apply, their application is saved in the database.
  - The button turns permanently to `Applied ✓ • Current Stage: <Stage>`.
  - Re-opening the modal or refreshing the page retains the exact applied state.
  - Zero chance of accidental double-applications or reset back to "Apply".

### 3. Real-Time 6-Stage Application Tracking Pipeline
Students and recruiters can monitor candidate progression across the **6 industry standard hiring stages**:
1. **Applied**: Candidate submitted credentials and match analysis.
2. **Shortlisted**: Recruiter reviewed profile and advanced candidate.
3. **Assessment**: Candidate invited to technical/aptitude proctored test.
4. **Interview**: Candidate scheduled for AI Mock or Corporate Panel interview.
5. **Selected**: Candidate passed all technical and HR rounds.
6. **Offer**: Official offer letter released to candidate.

### 4. Recruiter Fast-Forward Actions (`RecruiterPortalView.tsx`)
- Recruiter pipeline table features:
  - Direct Stage Selector dropdown (`Applied`, `Shortlisted`, `Assessment`, `Interview`, `Selected`, `Offer`, `Rejected`).
  - One-click sequential progression buttons (`Shortlist →`, `Assessment →`, `Interview →`, `Select →`, `Release Offer →`).
  - Stage changes instantly update the student's dashboard in real-time!

---

## 📦 What Is Included

### Backend (`server/`)
- `server/app/routes/recruiter.py`:
  - `POST /api/recruiter/opportunities`: Creates live job posting.
  - `GET /api/recruiter/applications`: Retrieves candidate submissions.
  - `PATCH /api/recruiter/applications/{app_id}/status`: Advances candidate stage.
- `server/app/routes/student.py`:
  - `POST /api/student/apply`: Persists student application.
  - `GET /api/student/applications`: Returns all applications for authenticated candidate.
- `server/app/data/canonical_store.json`: JSON store maintaining relational integrity between opportunities and applications.

### Frontend (`client/`)
- `client/src/views/RecruiterPortalView.tsx`: Full recruiter command center with job posting form and 6-stage candidate tracking table.
- `client/src/views/OpportunitiesView.tsx`: Student opportunity explorer with applied badges, active stage chips, and filtering.
- `client/src/components/modals/OpportunityModal.tsx`: Opportunity details modal with 6-stage visual pipeline tracker.

---

## 🚀 Quick Installation
1. Extract `job_posting_and_application_tracking.zip` into your project root.
2. Run the automated installer:
   ```bash
   python apply_job_posting_patch.py
   ```
