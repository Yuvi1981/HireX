import React, { useState, useEffect } from 'react';
import { MatchedOpportunity, StudentProfile } from '../types';
import { apiService } from '../services/api';
import { FileText, Printer, Mail, CheckCircle2, ShieldCheck, AlertCircle, Building2, Zap, Car, Sparkles, Clock, ShieldAlert } from 'lucide-react';
import { CounterfactualGuidanceModal } from '../components/modals/CounterfactualGuidanceModal';

interface OpportunitiesViewProps {
  opportunities: MatchedOpportunity[];
  student: StudentProfile;
  applications?: any[];
  onApplicationSubmitted?: (oppId: string, status?: string) => void;
  onOpenOpportunityDetail: (opp: MatchedOpportunity) => void;
  onOpenCoPilot: (prompt: string) => void;
}

export const OpportunitiesView: React.FC<OpportunitiesViewProps> = ({
  opportunities,
  student,
  applications,
  onApplicationSubmitted,
  onOpenOpportunityDetail,
  onOpenCoPilot
}) => {
  const [selectedOppId, setSelectedOppId] = useState<string>(opportunities[0]?.opportunity_id || 'opp_1');
  const [activeTab, setActiveTab] = useState<'drives' | 'ats_scanner' | 'funnel' | 'tpo_noc' | 'company_intel'>('drives');
  const [studentApps, setStudentApps] = useState<any[]>(applications || []);

  useEffect(() => {
    if (applications && applications.length > 0) {
      setStudentApps(applications);
    } else {
      const fetchApps = async () => {
        try {
          const res = await apiService.getStudentApplications(student?.id || 'std_1');
          if (res?.applications) {
            setStudentApps(res.applications);
          }
        } catch (err) {
          console.error('Failed to load applications in OpportunitiesView:', err);
        }
      };
      fetchApps();
    }
  }, [applications, student?.id]);

  const getApplicationForOpp = (opp: MatchedOpportunity) => {
    return studentApps.find(a => 
      a.opportunity_id === opp.opportunity_id ||
      a.opp_id === opp.opportunity_id ||
      a.opportunity_id === (opp as any).id ||
      (a.company?.toLowerCase() === opp.company?.toLowerCase() && a.title?.toLowerCase() === opp.title?.toLowerCase())
    );
  };
  const [driveFilter, setDriveFilter] = useState<'live' | 'archive'>('live');
  const [archivedDrives, setArchivedDrives] = useState<MatchedOpportunity[]>([]);
  const [loadingArchive, setLoadingArchive] = useState<boolean>(false);
  const [selectedCompanyIntel, setSelectedCompanyIntel] = useState<string>('barclays');
  const [nocPrinted, setNocPrinted] = useState<boolean>(false);
  const [isCounterfactualOpen, setIsCounterfactualOpen] = useState<boolean>(false);
  const [counterfactualOpp, setCounterfactualOpp] = useState<MatchedOpportunity | null>(null);

  // ATS Scanner state
  const [resumeText, setResumeText] = useState<string>(
    `Dhruv Patil | Computer Engineering, JSPM RSCOE Pune | CGPA: 8.92
Email: dhruv.patil@rscoe.edu.in | GitHub: github.com/dhruv-patil

SUMMARY:
Results-driven Full Stack AI Developer with proven expertise in building microservices and agentic applications. Architected responsive web frontends and engineered high-performance APIs.

TECHNICAL SKILLS:
Languages: Python, JavaScript, TypeScript, SQL
Frameworks: FastAPI, React, Node.js, Tailwind CSS
Databases: PostgreSQL, MongoDB
Core Concepts: Data Structures & Algorithms, REST APIs, Git, Linux

PROJECTS:
1. HireX - Autonomous Placement & Skill Verification Engine
• Engineered a multi-signal Ridge regression skill calibrator handling 15,000+ student profiles with <2ms inference.
• Built an in-browser AST code auditor that enforces linear O(N) runtime guarantees and flags quadratic loops.
• Integrated cryptographic SHA-256 validation for NPTEL and AWS certificates to eliminate fraudulent claims.

2. Distributed Microservices Task Engine
• Developed an asynchronous event queue in FastAPI and Redis, reducing worker latency by 35%.
• Deployed scalable services on Linux cloud servers with automated CI/CD pipelines.`
  );

  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanResult, setScanResult] = useState<any>(null);

  const handleToggleArchive = async (filter: 'live' | 'archive') => {
    setDriveFilter(filter);
    if (filter === 'archive' && archivedDrives.length === 0) {
      setLoadingArchive(true);
      try {
        const allOpps = await apiService.getOpportunities(student?.id || "std_1", true);
        const expiredOnly = allOpps.filter((o: MatchedOpportunity) => o.is_expired);
        setArchivedDrives(expiredOnly.length > 0 ? expiredOnly : [
          {
            opportunity_id: "opp_arch_legacy_1",
            title: "Stale Campus Drive (Expired)",
            company: "Legacy Tech Pvt Ltd",
            match_percentage: 65,
            matched_skills: ["SQL"],
            missing_skills: ["Java"],
            stipend: "₹30,000 / month",
            location: "Pune",
            duration: "3 Months",
            deadline: "2026-09-09",
            color_theme: "indigo",
            explanation: "Historical campus batch drive that closed on Sep 09, 2026.",
            is_expired: true,
            lifecycle_status: "EXPIRED",
            days_remaining: -27,
            urgency_label: "Drive Closed on Sep 09, 2026",
            can_apply: false,
            formatted_deadline: "September 09, 2026",
            verified_source_badge: "Historical Placement Record",
            risk_level: "LOW"
          }
        ]);
      } catch {
        // fallback
      } finally {
        setLoadingArchive(false);
      }
    }
  };

  const activeLiveDrives = opportunities.filter((o) => !o.is_expired);
  const currentDrives = driveFilter === 'live' ? activeLiveDrives : (archivedDrives.length > 0 ? archivedDrives : opportunities.filter(o => o.is_expired));
  const selectedOpp = currentDrives.find((o) => o.opportunity_id === selectedOppId) || currentDrives[0] || opportunities[0];

  const handleScanATS = async () => {
    setIsScanning(true);
    try {
      const res = await apiService.scanResumeFit(resumeText, selectedOppId);
      setScanResult(res.result);
    } catch {
      // fallback
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* 1. Header Bar with Sub-Navigation */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-5 rounded-2xl bg-white dark:bg-card-dark border border-slate-200/90 dark:border-slate-800 shadow-sm">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">Campus Placement Drives & TPO Gatekeeper</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Active corporate hiring drives for JSPM RSCOE, COEP, and PCCOE students with institutional eligibility clearance.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700">
          <button
            onClick={() => setActiveTab('drives')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              activeTab === 'drives'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Live Drives ({opportunities.length})
          </button>
          <button
            onClick={() => setActiveTab('ats_scanner')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              activeTab === 'ats_scanner'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            ATS Scanner
          </button>
          <button
            onClick={() => setActiveTab('funnel')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
              activeTab === 'funnel'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <span>Application Tracking</span>
            {studentApps.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-mono font-bold">
                {studentApps.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('tpo_noc')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              activeTab === 'tpo_noc'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            TPO NOC Clearance
          </button>
          <button
            onClick={() => setActiveTab('company_intel')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              activeTab === 'company_intel'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            National Recruiter Dossier
          </button>
        </div>
      </div>

      {/* 2. TPO Gatekeeping Eligibility Matrix Card */}
      <div className="p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 dark:bg-emerald-950/20 dark:border-emerald-800/30">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300">
                Institutional TPO Clearance Matrix — JSPM RSCOE
              </span>
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1">
              Candidate Academic Clearance: APPROVED FOR ALL PAN-INDIA & CAMPUS DRIVES
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
              Verified with Controller of Examinations (SPPU). Zero active backlogs, CGPA exceeds criteria for Barclays, Persistent, and Tata Tech.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full lg:w-auto">
            <div className="p-2.5 rounded-xl bg-white/80 dark:bg-slate-900/80 border border-emerald-500/20 text-center">
              <span className="text-[10px] text-slate-500 block">10th SSC</span>
              <span className="text-xs font-bold text-emerald-600">88.5% (Req: 60%)</span>
            </div>
            <div className="p-2.5 rounded-xl bg-white/80 dark:bg-slate-900/80 border border-emerald-500/20 text-center">
              <span className="text-[10px] text-slate-500 block">12th HSC</span>
              <span className="text-xs font-bold text-emerald-600">84.2% (Req: 60%)</span>
            </div>
            <div className="p-2.5 rounded-xl bg-white/80 dark:bg-slate-900/80 border border-emerald-500/20 text-center">
              <span className="text-[10px] text-slate-500 block">Current CGPA</span>
              <span className="text-xs font-bold text-emerald-600">8.92 (Req: 7.5)</span>
            </div>
            <div className="p-2.5 rounded-xl bg-white/80 dark:bg-slate-900/80 border border-emerald-500/20 text-center">
              <span className="text-[10px] text-slate-500 block">Live Backlogs</span>
              <span className="text-xs font-bold text-emerald-600">0 (Max: 0)</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Tab Body */}
      {activeTab === 'drives' && (
        <div className="space-y-4">
          {/* Sub-Filters: Live Drives vs Past Drives Archive */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3 rounded-2xl bg-white dark:bg-card-dark border border-slate-200/90 dark:border-slate-800 shadow-xs">
            <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700">
              <button
                onClick={() => handleToggleArchive('live')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                  driveFilter === 'live'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Active Live Drives ({activeLiveDrives.length})</span>
              </button>
              <button
                onClick={() => handleToggleArchive('archive')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                  driveFilter === 'archive'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>Past Drives Archive ({archivedDrives.length || (driveFilter === 'archive' ? currentDrives.length : 1)})</span>
              </button>
            </div>
            {driveFilter === 'archive' ? (
              <span className="text-[11px] text-amber-600 dark:text-amber-400 font-medium flex items-center gap-1">
                <Clock className="w-3 h-3" /> Historical placement records for cutoffs and stipend benchmarking (Read-Only)
              </span>
            ) : (
              <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> 100% Active & Time-Aware Verified (Ghost & Stale Postings Discarded)
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Opportunities List */}
            <div className="lg:col-span-2 space-y-4">
              {currentDrives.map((opp) => {
                const isSelected = opp.opportunity_id === selectedOppId;
                const appRecord = getApplicationForOpp(opp);
                const isApplied = !!appRecord;
                const currentStage = appRecord?.status || appRecord?.stage || 'Applied';

                return (
                  <div
                    key={opp.opportunity_id}
                    onClick={() => setSelectedOppId(opp.opportunity_id)}
                    className={`p-6 rounded-2xl bg-white dark:bg-card-dark border transition cursor-pointer shadow-sm ${
                      isSelected
                        ? 'border-slate-900 dark:border-white ring-2 ring-slate-900/10 dark:ring-white/10 shadow-md'
                        : 'border-slate-200/90 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="text-base font-bold text-slate-900 dark:text-white tracking-tight">{opp.title}</h3>
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                            {opp.match_percentage}% Verified Match
                          </span>
                          {isApplied && (
                            <span className="px-2.5 py-0.5 rounded-md text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              Applied • Stage: {currentStage}
                            </span>
                          )}
                          {((opp as any).jdFit || (opp as any).jd_fit) && (
                            <span
                              className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold border ${
                                ((opp as any).jdFit?.verdict === 'STRONG_FIT' || (opp as any).jd_fit?.verdict === 'STRONG_FIT')
                                  ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                                  : ((opp as any).jdFit?.verdict === 'GOOD_FIT' || (opp as any).jd_fit?.verdict === 'GOOD_FIT')
                                  ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300 border-blue-200 dark:border-blue-800'
                                  : ((opp as any).jdFit?.verdict === 'PARTIAL_FIT' || (opp as any).jd_fit?.verdict === 'PARTIAL_FIT')
                                  ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                                  : 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border-rose-200 dark:border-rose-800'
                              }`}
                            >
                              JD Fit: {((opp as any).jdFit?.score ?? (opp as any).jd_fit?.score)}% {
                                (((opp as any).jdFit?.verdict || (opp as any).jd_fit?.verdict) || '').replace('_', ' ')
                              }
                            </span>
                          )}
                          {opp.is_expired ? (
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                              Drive Closed ({opp.formatted_deadline || opp.deadline})
                            </span>
                          ) : (opp.lifecycle_status === 'CLOSING_SOON' || (opp.days_remaining !== undefined && opp.days_remaining <= 3)) ? (
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-50 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300 border border-amber-200 dark:border-amber-800 flex items-center gap-1">
                              {opp.urgency_label || '⚡ Closes Soon'}
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-medium bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                              {opp.urgency_label || `Due in ${opp.days_remaining || 30} days`}
                            </span>
                          )}
                        </div>
                        <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mt-1">
                          {opp.company} • {opp.location} • {opp.stipend}
                        </p>
                      </div>

                      <div className="shrink-0 text-right">
                        <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 block">
                          {opp.verified_source_badge || "TPO Cleared"}
                        </span>
                        <span className="text-[10px] text-slate-400">Deadline: {opp.deadline}</span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-3 line-clamp-2">
                      {opp.explanation}
                    </p>

                    <div className="flex flex-wrap items-center justify-between gap-3 mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80">
                      <div className="flex flex-wrap items-center gap-1.5">
                        {opp.matched_skills.map((s) => (
                          <span key={s} className="px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-[10px] font-semibold">
                            ✓ {s}
                          </span>
                        ))}
                        {opp.missing_skills.map((s) => (
                          <span key={s} className="px-2 py-0.5 rounded-md bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 text-[10px] font-semibold">
                            + {s} (Missing)
                          </span>
                        ))}
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setCounterfactualOpp(opp);
                            setIsCounterfactualOpen(true);
                          }}
                          className="px-3 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 text-xs font-bold transition flex items-center gap-1.5 border border-purple-200 dark:border-purple-800/60"
                        >
                          <Sparkles className="w-3.5 h-3.5 text-purple-500" />
                          <span>Explain Fit & Bridge Gap</span>
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenCoPilot(`Check my readiness for ${opp.company}`);
                          }}
                          className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold transition flex items-center gap-1.5"
                        >
                          <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                          <span>Ask Agent</span>
                        </button>
                        {isApplied ? (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onOpenOpportunityDetail(opp);
                            }}
                            className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-sm flex items-center gap-1.5"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Applied ({currentStage})</span>
                          </button>
                        ) : (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onOpenOpportunityDetail(opp);
                            }}
                            className="px-4 py-1.5 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold transition shadow-sm"
                          >
                            Drive Details →
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Quick Drive Sidebar Details */}
            <div className="space-y-4">
              {(() => {
                const selectedOppApp = getApplicationForOpp(selectedOpp);
                const isSelectedApplied = !!selectedOppApp;
                const selectedStage = selectedOppApp?.status || selectedOppApp?.stage || 'Applied';
                const stagesList = ['Applied', 'Shortlisted', 'Assessment', 'Interview', 'Selected', 'Offer'];

                return (
                  <div className="p-6 rounded-2xl bg-white dark:bg-card-dark border border-slate-200/90 dark:border-slate-800 shadow-sm">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
                      Selected Recruitment Drive
                    </span>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white mt-1 tracking-tight">
                      {selectedOpp.company}
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-300 font-semibold">{selectedOpp.title}</p>

                    {/* Application Tracking banner if applied */}
                    {isSelectedApplied && (
                      <div className="mt-4 p-4 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-emerald-900 dark:text-emerald-200 flex items-center gap-1.5">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                            Application Active
                          </span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-200 text-emerald-900 dark:bg-emerald-900 dark:text-emerald-100">
                            {selectedStage}
                          </span>
                        </div>
                        <p className="text-[11px] text-emerald-800 dark:text-emerald-300 leading-relaxed">
                          Track applications through Applied, Shortlisted, Assessment, Interview, Selected, and Offer stages.
                        </p>
                        <div className="grid grid-cols-6 gap-1 pt-1">
                          {stagesList.map((stg, i) => {
                            const activeIdx = stagesList.findIndex(s => s.toLowerCase() === selectedStage.toLowerCase());
                            const isPast = activeIdx !== -1 && i < activeIdx;
                            const isCurrent = selectedStage.toLowerCase() === stg.toLowerCase();
                            return (
                              <div key={stg} className="text-center" title={stg}>
                                <div className={`h-1.5 rounded-full mb-1 transition-all ${
                                  isCurrent ? 'bg-emerald-500 ring-2 ring-emerald-400/40' :
                                  isPast ? 'bg-indigo-600' : 'bg-slate-200 dark:bg-slate-700'
                                }`} />
                                <span className={`text-[8px] truncate block ${isCurrent ? 'font-bold text-emerald-700 dark:text-emerald-300' : 'text-slate-400'}`}>
                                  {stg.slice(0, 3)}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Pillar 4: Expired Drive Advisory Banner in Sidebar */}
                    {selectedOpp.is_expired && (
                      <div className="mt-4 p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-200 text-xs">
                        <p className="font-bold flex items-center gap-1.5">
                          <AlertCircle className="w-4 h-4 text-amber-600" />
                          Drive Closed
                        </p>
                        <p className="mt-1 text-[11px] text-amber-700 dark:text-amber-300 leading-relaxed">
                          This drive closed on {selectedOpp.formatted_deadline || selectedOpp.deadline} and is no longer accepting submissions. Retained for historical eligibility and stipend benchmarking.
                        </p>
                      </div>
                    )}

                    <div className="space-y-3 mt-4 text-xs">
                      <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                        <span className="text-slate-500">Compensation:</span>
                        <span className="font-bold text-slate-800 dark:text-slate-200 font-mono">{selectedOpp.stipend}</span>
                      </div>
                      <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                        <span className="text-slate-500">Location:</span>
                        <span className="font-bold text-slate-800 dark:text-slate-200">{selectedOpp.location}</span>
                      </div>
                      <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                        <span className="text-slate-500">Source Verification:</span>
                        <span className="font-bold text-indigo-600 dark:text-indigo-400 font-mono">
                          {selectedOpp.verified_source_badge || "Direct Employer Verified"}
                        </span>
                      </div>
                      <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                        <span className="text-slate-500">Drive Rounds:</span>
                        <span className="font-bold text-slate-800 dark:text-slate-200">Aptitude → Coding → Tech → HR</span>
                      </div>
                      <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                        <span className="text-slate-500">Eligibility Status:</span>
                        <span className="font-bold text-emerald-600 font-mono">Passed (TPO Signed)</span>
                      </div>
                    </div>

                    <div className="mt-6 space-y-2">
                      <button
                        onClick={() => {
                          setActiveTab('ats_scanner');
                        }}
                        className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-black dark:bg-white dark:hover:bg-slate-100 dark:text-slate-900 text-white text-xs font-bold transition shadow-xs flex items-center justify-center gap-1.5"
                      >
                        Scan Resume with ATS for this Job
                      </button>
                      <button
                        onClick={() => {
                          setCounterfactualOpp(selectedOpp);
                          setIsCounterfactualOpen(true);
                        }}
                        className="w-full py-2.5 rounded-xl bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 text-xs font-bold transition flex items-center justify-center gap-1.5 border border-purple-200 dark:border-purple-800/60 shadow-xs"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-purple-500" />
                        <span>Explain Fit & Bridge Gap (AI)</span>
                      </button>
                      {isSelectedApplied ? (
                        <button
                          onClick={() => onOpenOpportunityDetail(selectedOpp)}
                          className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-xs flex items-center justify-center gap-1.5"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Applied ✓ • Stage: {selectedStage}</span>
                        </button>
                      ) : selectedOpp.is_expired ? (
                        <button
                          disabled
                          className="w-full py-2.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-500 text-xs font-bold cursor-not-allowed flex items-center justify-center gap-1.5"
                        >
                          Drive Closed on {selectedOpp.formatted_deadline || selectedOpp.deadline}
                        </button>
                      ) : (
                        <button
                          onClick={() => onOpenOpportunityDetail(selectedOpp)}
                          className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition"
                        >
                          Submit Official TPO Application
                        </button>
                      )}
                    </div>
                  </div>
                );
              })()}

            <div className="p-5 rounded-2xl bg-slate-900 text-white border border-slate-800 shadow-sm">
              <h4 className="text-sm font-bold flex items-center gap-2 text-slate-100">
                Barclays Interview Tip
              </h4>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Barclays India (Bengaluru & Pune) technical rounds heavily test asynchronous Python (FastAPI/asyncio) and strict O(N) hashmap algorithms. Practice inside the Code Lab before your interview slot.
              </p>
            </div>
          </div>
        </div>
      </div>
      )}

      {/* ATS Scanner Tab */}
      {activeTab === 'ats_scanner' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-card-dark border border-slate-200/90 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white tracking-tight">Enterprise ATS Resume Evaluator</h3>
                <p className="text-xs text-slate-500">
                  Matching against: <span className="font-bold text-slate-800 dark:text-slate-200">{selectedOpp.company} — {selectedOpp.title}</span>
                </p>
              </div>
              <button
                onClick={handleScanATS}
                disabled={isScanning}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold transition shadow-xs disabled:opacity-50"
              >
                {isScanning ? "Evaluating Vector Overlap..." : "Run ATS Scan"}
              </button>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Candidate Resume Markdown / Plaintext
              </label>
              <textarea
                value={resumeText}
                onChange={(e) => setResumeText(e.target.value)}
                rows={14}
                className="w-full p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-mono text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-indigo/40 resize-none leading-relaxed"
                placeholder="Paste your resume content here..."
              />
            </div>
          </div>

          {/* ATS Scan Results */}
          <div className="space-y-4">
            {scanResult ? (
              <div className="p-6 rounded-2xl bg-white dark:bg-card-dark border border-slate-200/90 dark:border-slate-800 shadow-xs space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      ATS Screening Verdict
                    </span>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                      {scanResult.verdict}
                    </h3>
                  </div>
                  <div className="w-14 h-14 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/60 dark:border-emerald-800/60 flex flex-col items-center justify-center text-emerald-700 dark:text-emerald-300 font-mono font-bold text-xl">
                    <span>{scanResult.ats_score}</span>
                    <span className="text-[9px] font-semibold text-emerald-600/80">/ 100</span>
                  </div>
                </div>

                <div>
                  <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">Matched Core Keywords</h4>
                  <div className="flex flex-wrap gap-1.5">
                    {scanResult.matched_keywords?.map((k: string) => (
                      <span key={k} className="px-2.5 py-1 rounded-md bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/60 dark:border-emerald-800/40 text-emerald-700 dark:text-emerald-300 text-xs font-medium">
                        ✓ {k}
                      </span>
                    ))}
                  </div>
                </div>

                {scanResult.missing_keywords?.length > 0 && (
                  <div>
                    <h4 className="text-xs font-bold text-amber-700 dark:text-amber-400 mb-2">Missing Priority Keywords</h4>
                    <div className="flex flex-wrap gap-1.5">
                      {scanResult.missing_keywords?.map((k: string) => (
                        <span key={k} className="px-2.5 py-1 rounded-md bg-amber-50 dark:bg-amber-950/40 border border-amber-200/60 dark:border-amber-800/40 text-amber-700 dark:text-amber-300 text-xs font-medium inline-flex items-center gap-1">
                          <AlertCircle className="w-3 h-3 text-amber-600" />
                          <span>{k}</span>
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <div>
                  <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">Actionable Bullet Suggestions</h4>
                  <ul className="text-xs text-slate-600 dark:text-slate-300 space-y-1.5">
                    {scanResult.suggestions?.map((s: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-slate-900 dark:text-slate-100 font-bold">•</span>
                        <span>{s}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ) : (
              <div className="p-8 rounded-2xl bg-white dark:bg-card-dark border border-dashed border-slate-200 dark:border-slate-800 text-center flex flex-col items-center justify-center h-full min-h-[300px]">
                <div className="w-12 h-12 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-500 mb-3">
                  <FileText className="w-6 h-6" />
                </div>
                <h4 className="text-base font-bold text-slate-800 dark:text-slate-200">No ATS Scan Run Yet</h4>
                <p className="text-xs text-slate-500 max-w-sm mt-1">
                  Click 'Run ATS Scan' on the left to evaluate your resume against {selectedOpp.company}'s automated screening algorithm.
                </p>
                <button
                  onClick={handleScanATS}
                  className="mt-4 px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold transition shadow-xs"
                >
                  Run ATS Compatibility Scan →
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Application Tracker Funnel Tab */}
      {activeTab === 'funnel' && (
        <div className="p-6 rounded-2xl bg-white dark:bg-card-dark border border-slate-200/90 dark:border-slate-800 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Application Tracking</h3>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Track applications through Applied, Shortlisted, Assessment, Interview, Selected, and Offer stages.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                {studentApps.length} Application{studentApps.length !== 1 ? 's' : ''} Tracked
              </span>
            </div>
          </div>

          {/* 6-Stage Tracking Funnel Columns */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
            {[
              { id: 'Applied', label: '1. Applied', color: 'slate', desc: 'Credentials & Match Submitted' },
              { id: 'Shortlisted', label: '2. Shortlisted', color: 'indigo', desc: 'Screened by Recruiter' },
              { id: 'Assessment', label: '3. Assessment', color: 'purple', desc: 'Aptitude & Coding Round' },
              { id: 'Interview', label: '4. Interview', color: 'amber', desc: 'Technical & HR Rounds' },
              { id: 'Selected', label: '5. Selected', color: 'emerald', desc: 'Selection Decision Approved' },
              { id: 'Offer', label: '6. Offer', color: 'teal', desc: 'Official Offer Released' }
            ].map((stg) => {
              const stageApps = studentApps.filter(a => {
                const s = (a.status || a.stage || 'Applied').toLowerCase();
                return s === stg.id.toLowerCase();
              });

              return (
                <div
                  key={stg.id}
                  className="p-3.5 rounded-xl bg-slate-50/70 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200">{stg.label}</span>
                      <span className="px-2 py-0.5 rounded-md font-mono text-[10px] font-bold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300">
                        {stageApps.length}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 mb-3">{stg.desc}</p>

                    <div className="space-y-2">
                      {stageApps.length === 0 ? (
                        <div className="py-6 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-lg">
                          <span className="text-[10px] text-slate-400 italic">No candidates in this stage</span>
                        </div>
                      ) : (
                        stageApps.map((app: any) => (
                          <div
                            key={app.id || app.opportunity_id}
                            onClick={() => {
                              const matchedOpp = opportunities.find(o => 
                                o.opportunity_id === app.opportunity_id || 
                                o.opportunity_id === app.opp_id || 
                                o.company?.toLowerCase() === app.company?.toLowerCase()
                              );
                              if (matchedOpp) onOpenOpportunityDetail(matchedOpp);
                            }}
                            className="p-2.5 rounded-lg bg-white dark:bg-card-dark text-xs shadow-xs border border-slate-200/80 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-600 transition cursor-pointer"
                          >
                            <div className="flex items-start justify-between gap-1">
                              <span className="font-bold text-slate-900 dark:text-white truncate block">{app.company}</span>
                              {app.match_percentage && (
                                <span className="text-[10px] font-mono font-bold text-emerald-600 dark:text-emerald-400 shrink-0">
                                  {app.match_percentage}%
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-500 dark:text-slate-400 block truncate">{app.title}</span>
                            <div className="mt-2 pt-1.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[9px] text-slate-400">
                              <span>{app.applied_at ? new Date(app.applied_at).toLocaleDateString() : 'Active'}</span>
                              <span className="text-indigo-600 dark:text-indigo-400 font-bold">Details →</span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 5. TPO No-Objection Certificate (NOC) Generator Tab */}
      {activeTab === 'tpo_noc' && (
        <div className="space-y-6">
          {/* NOC Verification Status Card */}
          <div className="p-6 rounded-2xl bg-white dark:bg-card-dark border border-slate-200/90 dark:border-slate-800 shadow-xs">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-5 border-b border-slate-100 dark:border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/60 dark:border-emerald-800/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                    <FileText className="w-4 h-4" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                    TPO Institutional Clearance & NOC Generator
                  </h3>
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/60">
                    All Criteria Passed
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Automated SPPU & AICTE compliant internship clearance with live academic criteria validation.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setNocPrinted(true);
                    window.print();
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold transition shadow-xs flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print / Save PDF</span>
                </button>
                <button
                  onClick={() => onOpenCoPilot("Generate an email draft to the JSPM RSCOE TPO requesting official NOC endorsement for my Barclays internship.")}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-200 text-xs font-bold transition flex items-center gap-1.5 border border-slate-200 dark:border-slate-700"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Draft TPO Email</span>
                </button>
              </div>
            </div>

            {/* Live Criteria Verification Checklist */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 my-4">
              <div className="p-3 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-800/40 text-xs">
                <div className="flex items-center justify-between text-emerald-800 dark:text-emerald-300 font-bold mb-1">
                  <span>1. Minimum CGPA (7.5+)</span>
                  <span className="font-mono text-[10px] font-bold text-emerald-600">✓ PASSED</span>
                </div>
                <span className="text-slate-600 dark:text-slate-400 font-mono text-[11px]">Student CGPA: 8.92 / 10.0</span>
              </div>

              <div className="p-3 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-800/40 text-xs">
                <div className="flex items-center justify-between text-emerald-800 dark:text-emerald-300 font-bold mb-1">
                  <span>2. Backlog Clearance</span>
                  <span className="font-mono text-[10px] font-bold text-emerald-600">✓ 0 BACKLOGS</span>
                </div>
                <span className="text-slate-600 dark:text-slate-400 font-mono text-[11px]">All 6 Semesters Cleared</span>
              </div>

              <div className="p-3 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-800/40 text-xs">
                <div className="flex items-center justify-between text-emerald-800 dark:text-emerald-300 font-bold mb-1">
                  <span>3. Min Attendance (75%)</span>
                  <span className="font-mono text-[10px] font-bold text-emerald-600">✓ 86.4%</span>
                </div>
                <span className="text-slate-600 dark:text-slate-400 font-mono text-[11px]">Biometric Department Log</span>
              </div>

              <div className="p-3 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-800/40 text-xs">
                <div className="flex items-center justify-between text-emerald-800 dark:text-emerald-300 font-bold mb-1">
                  <span>4. CodeLab AST Verified</span>
                  <span className="font-mono text-[10px] font-bold text-emerald-600">✓ CERTIFIED</span>
                </div>
                <span className="text-slate-600 dark:text-slate-400 font-mono text-[11px]">O(N) Complexity Verified</span>
              </div>
            </div>

            {/* Official Printable NOC Document Container */}
            <div className="p-8 sm:p-10 rounded-xl bg-slate-50/70 dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 max-w-3xl mx-auto relative font-serif">
              {/* College Watermark Stamp */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-5 pointer-events-none text-9xl font-black font-sans select-none">
                RSCOE
              </div>

              {/* Header Letterhead */}
              <div className="text-center pb-4 border-b-2 border-slate-900 dark:border-slate-300">
                <h2 className="text-base sm:text-lg font-black tracking-wide text-slate-900 dark:text-white uppercase font-sans">
                  JSPM's Rajarshi Shahu College of Engineering, Pune
                </h2>
                <p className="text-[11px] text-slate-600 dark:text-slate-400 font-sans">
                  (An Autonomous Institute Affiliated to Savitribai Phule Pune University | AICTE Approved | NAAC 'A' Grade)
                </p>
                <p className="text-[10px] text-slate-500 font-sans mt-0.5">
                  Tathawade, Pune - 411033, Maharashtra, India • Office of the Dean, Training & Placement
                </p>
              </div>

              {/* Reference & Date */}
              <div className="flex justify-between items-center text-xs my-4 font-mono">
                <span>Ref: SPPU/RSCOE/TPO/2026/NOC-4891</span>
                <span>Date: October 5, 2026</span>
              </div>

              {/* Title */}
              <div className="text-center my-4">
                <h3 className="text-sm font-bold tracking-wider uppercase underline font-sans">
                  NO OBJECTION CERTIFICATE (CAMPUS INTERNSHIP)
                </h3>
              </div>

              {/* Body */}
              <div className="text-xs sm:text-sm leading-relaxed space-y-3 font-sans text-justify">
                <p>
                  This is to certify that <strong>Mr. Dhruv Patil</strong> (PRN: <strong>72148291B</strong>) is a bonafide, regular student of this institute pursuing his <strong>Bachelor of Technology (B.Tech) in Computer Engineering</strong> in Semester VI (Academic Year 2025-2026).
                </p>
                <p>
                  As per institutional academic audit records, the student has maintained an overall <strong>CGPA of 8.92</strong> with <strong>0 active backlogs</strong> and an overall department attendance of <strong>86.4%</strong>. The student has also completed the institutional HireX AST code audits and NPTEL certifications.
                </p>
                <p>
                  The Training and Placement Cell has <strong>NO OBJECTION</strong> to Mr. Dhruv Patil undertaking a full-time / part-time industrial internship with <strong>{selectedOpp.company}</strong> starting from the stipulated recruitment schedule. Academic credits for the internship will be credited through the National Credit Framework (NCrF 4.0).
                </p>
              </div>

              {/* Signature Section */}
              <div className="flex justify-between items-end pt-8 mt-6 border-t border-slate-200 dark:border-slate-800 font-sans text-xs">
                <div>
                  <div className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 inline-block font-mono text-[9px] text-slate-600 dark:text-slate-400">
                    <div>DIGITAL VERIFICATION HASH:</div>
                    <div className="font-bold text-slate-900 dark:text-white">SHA256: 7f83b1657ff1...rscoe_tpo</div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-bold text-sm text-slate-900 dark:text-white">
                    Dr. S. K. Mahajan
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Dean, Training & Placement
                  </div>
                  <div className="text-[10px] text-indigo-600 dark:text-indigo-400 font-bold">
                    JSPM RSCOE Pune
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 6. Pune Recruiter Intel Dossier Tab */}
      {activeTab === 'company_intel' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-card-dark border border-slate-200/90 dark:border-slate-800 shadow-xs">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-5 border-b border-slate-100 dark:border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200/60 dark:border-indigo-800/60 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                    National Campus Recruiter Intel Dossier
                  </h3>
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300 border border-indigo-200/60 dark:border-indigo-800/60">
                    Past 3 Years Hiring Intel
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Inside telemetry, interview stages, and technical expectations for top Indian tech and product employers across Bengaluru, Hyderabad, and Pune.
                </p>
              </div>

              {/* Company Selector */}
              <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700">
                {[
                  { id: 'barclays', label: 'Barclays India', icon: Building2 },
                  { id: 'persistent', label: 'Persistent Systems', icon: Zap },
                  { id: 'tatatech', label: 'Tata Technologies', icon: Car }
                ].map((c) => {
                  const Icon = c.icon;
                  return (
                    <button
                      key={c.id}
                      onClick={() => setSelectedCompanyIntel(c.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                        selectedCompanyIntel === c.id
                          ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{c.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Selected Company Deep Dive Dossier */}
            {selectedCompanyIntel === 'barclays' && (
              <div className="mt-5 space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Annual CTC Package</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white block mt-0.5">₹12.5 - 14.0 LPA</span>
                    <span className="text-[11px] text-emerald-600 font-semibold">+ ₹50,000/mo Internship</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">National Tech Hubs</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white block mt-0.5">Bengaluru & Pune</span>
                    <span className="text-[11px] text-slate-500">Global Innovation Centres</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Cutoff Eligibility</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white block mt-0.5">80% HireX Score</span>
                    <span className="text-[11px] text-emerald-600 font-semibold">Your Score: 88% (Eligible)</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Selection Ratio</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white block mt-0.5">3.8% of Applicants</span>
                    <span className="text-[11px] text-indigo-600 font-semibold">High Tech Rigor</span>
                  </div>
                </div>

                {/* 4-Stage Interview Breakdown */}
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">
                    Barclays 4-Round Selection Funnel
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
                    <div className="p-3 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                      <span className="font-bold text-slate-900 dark:text-white block">Round 1: Cognitive & Tech</span>
                      <span className="text-[11px] text-slate-500 mt-1 block">45 Questions (Quant, Verbal, Core CS). 45-second speed threshold enforced.</span>
                    </div>
                    <div className="p-3 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                      <span className="font-bold text-slate-900 dark:text-white block">Round 2: Algorithmic AST</span>
                      <span className="text-[11px] text-slate-500 mt-1 block">2 LeetCode Mediums. Enforces linear O(N) complexity checks.</span>
                    </div>
                    <div className="p-3 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                      <span className="font-bold text-slate-900 dark:text-white block">Round 3: System Architecture</span>
                      <span className="text-[11px] text-slate-500 mt-1 block">FastAPI, Microservices, Caching (Redis), Database Indexing.</span>
                    </div>
                    <div className="p-3 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                      <span className="font-bold text-slate-900 dark:text-white block">Round 4: Values & Techno-HR</span>
                      <span className="text-[11px] text-slate-500 mt-1 block">Barclays RISCE Values (Respect, Integrity, Service, Excellence, Stewardship).</span>
                    </div>
                  </div>
                </div>

                {/* Frequently Asked Technical Questions */}
                <div className="p-4 rounded-xl bg-white dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                      Most Frequent National Campus Questions (2024-2026)
                    </h4>
                    <button
                      onClick={() => onOpenCoPilot("Walk me through the top 5 technical interview questions asked by Barclays India campus drives and how to solve them in optimal O(N) time.")}
                      className="text-xs font-bold text-slate-900 dark:text-slate-100 hover:underline flex items-center gap-1"
                    >
                      <span>Practice in AI Co-Pilot →</span>
                    </button>
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800 flex items-center justify-between">
                      <span className="font-medium text-slate-800 dark:text-slate-200">1. Maximum Subarray Sum with Dynamic Programming (Kadane's Algorithm)</span>
                      <span className="text-[10px] font-mono text-indigo-600 font-bold">Tested in CodeLab</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800 flex items-center justify-between">
                      <span className="font-medium text-slate-800 dark:text-slate-200">2. Explain ACID properties with real PostgreSQL transaction rollback examples</span>
                      <span className="text-[10px] font-mono text-purple-600 font-bold">Core CS</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800 flex items-center justify-between">
                      <span className="font-medium text-slate-800 dark:text-slate-200">3. How does asynchronous concurrency work in Python FastAPI vs Node.js Event Loop?</span>
                      <span className="text-[10px] font-mono text-emerald-600 font-bold">Industry Gap Lab</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Persistent Systems Dossier */}
            {selectedCompanyIntel === 'persistent' && (
              <div className="mt-5 space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Annual Package</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white block mt-0.5">₹9.0 - 11.5 LPA</span>
                    <span className="text-[11px] text-emerald-600 font-semibold">+ ₹35,000/mo Internship</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">National Tech Hubs</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white block mt-0.5">Pune & Hyderabad</span>
                    <span className="text-[11px] text-slate-500">Digital Engineering Labs</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Cutoff Score</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white block mt-0.5">75% HireX Score</span>
                    <span className="text-[11px] text-emerald-600 font-semibold">Your Score: 88% (Eligible)</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Primary Stacks</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white block mt-0.5">Cloud, AI, Java</span>
                    <span className="text-[11px] text-indigo-600 font-semibold">Enterprise Engineering</span>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800 text-xs">
                  <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-2">
                    Persistent Systems Focus: GenAI & Cloud Integrations
                  </h4>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                    Persistent evaluates candidates heavily on their hands-on ability to build and deploy APIs rather than purely theoretical textbook memorization. Your verified Python AST badges and FastAPI project directly elevate your resume into their fast-track interview pool.
                  </p>
                </div>
              </div>
            )}

            {/* Tata Technologies Dossier */}
            {selectedCompanyIntel === 'tatatech' && (
              <div className="mt-5 space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Annual Package</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white block mt-0.5">₹7.5 - 9.0 LPA</span>
                    <span className="text-[11px] text-emerald-600 font-semibold">+ ₹30,000/mo Internship</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">National Tech Hubs</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white block mt-0.5">Bengaluru & Pune</span>
                    <span className="text-[11px] text-slate-500">Automotive Embedded & IoT</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Cutoff Score</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white block mt-0.5">70% HireX Score</span>
                    <span className="text-[11px] text-emerald-600 font-semibold">Your Score: 88% (Eligible)</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Focus</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white block mt-0.5">Connected Vehicles</span>
                    <span className="text-[11px] text-indigo-600 font-semibold">IoT & Systems Code</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* AI Explainability & Counterfactual Guidance Modal */}
      <CounterfactualGuidanceModal
        isOpen={isCounterfactualOpen}
        onClose={() => {
          setIsCounterfactualOpen(false);
          setCounterfactualOpp(null);
        }}
        opportunityId={counterfactualOpp?.opportunity_id || selectedOppId}
        studentId={student.id || "std_1"}
        opportunityTitle={counterfactualOpp?.title || selectedOpp.title}
        companyName={counterfactualOpp?.company || selectedOpp.company}
      />
    </div>
  );
};

