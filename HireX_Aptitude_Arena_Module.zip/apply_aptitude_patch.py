#!/usr/bin/env python3
"""
HireX Aptitude Arena Intelligent Drop-in Installer.
Installs and integrates the Aptitude Arena module into any target HireX installation:
- Automatically detects project root directory.
- Copies all backend services, seed banks, test suites, and frontend components.
- Integrates the router in server/app/main.py if not already present.
- Executes the test suite to verify 100% test integrity.
"""

import os
import sys
import shutil
import subprocess
import re

def log(msg):
    print(f"[HireX Aptitude Installer] {msg}")

def find_project_root():
    cwd = os.path.abspath(os.getcwd())
    if os.path.exists(os.path.join(cwd, "server")) and os.path.exists(os.path.join(cwd, "client")):
        return cwd
    script_dir = os.path.abspath(os.path.dirname(__file__))
    if os.path.exists(os.path.join(script_dir, "server")) and os.path.exists(os.path.join(script_dir, "client")):
        return script_dir
    parent = os.path.dirname(script_dir)
    if os.path.exists(os.path.join(parent, "server")) and os.path.exists(os.path.join(parent, "client")):
        return parent
    return None

def main():
    root_dir = find_project_root()
    if not root_dir:
        print("[ERROR] Could not locate HireX project root directory (containing 'server' and 'client').")
        sys.exit(1)

    log(f"Target HireX root: {root_dir}")
    source_dir = os.path.abspath(os.path.dirname(__file__))

    # 1. Copy Files
    for root, dirs, files in os.walk(source_dir):
        for f in files:
            if f in ["apply_aptitude_patch.py", "README_APTITUDE_ARENA.md"]:
                continue
            src_full = os.path.join(root, f)
            rel = os.path.relpath(src_full, source_dir)
            dst_full = os.path.join(root_dir, rel)
            os.makedirs(os.path.dirname(dst_full), exist_ok=True)
            shutil.copy2(src_full, dst_full)
            log(f"Installed: {rel}")

    # 2. Patch server/app/main.py if router not included
    main_py = os.path.join(root_dir, "server", "app", "main.py")
    if os.path.exists(main_py):
        with open(main_py, "r", encoding="utf-8") as f:
            content = f.read()
        if "aptitude" not in content:
            if "from app.routes import" in content:
                content = re.sub(r"from app\.routes import ([^\n]+)", r"from app.routes import \1, aptitude", content, count=1)
            if "app.include_router(aptitude.router)" not in content:
                content = content.replace("app.include_router(", "app.include_router(aptitude.router)\napp.include_router(", 1)
            with open(main_py, "w", encoding="utf-8") as f:
                f.write(content)
            log("Patched server/app/main.py with aptitude.router")
        else:
            log("server/app/main.py already configured with aptitude router.")

    # 3. Run validation tests
    log("Running automated validation test suite (pytest)...")
    env = os.environ.copy()
    env["PYTHONPATH"] = os.path.join(root_dir, "server")
    try:
        res = subprocess.run(
            [sys.executable, "-m", "pytest", "server/tests/test_aptitude_system.py"],
            cwd=root_dir,
            env=env,
            capture_output=True,
            text=True
        )
        if res.returncode == 0:
            log("SUCCESS! All 8 Aptitude Arena test cases PASSED (100% green)!")
        else:
            log(f"Pytest return code: {res.returncode}")
            log(f"Pytest output:\n{res.stdout}\n{res.stderr}")
    except Exception as e:
        log(f"Note: Could not automatically invoke pytest: {e}")

    log("Aptitude Arena installation complete!")

if __name__ == "__main__":
    main()
