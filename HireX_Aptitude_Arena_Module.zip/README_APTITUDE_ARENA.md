# 🎯 HireX: Gamified & Standardized Aptitude Arena Subsystem

The **Aptitude Arena** is HireX's cognitive assessment engine combining:
1. **Standardized Exam & Practice Modes**: 450+ vetted questions across 9 aptitude domains with step-by-step mathematical explanations.
2. **Gamified Cognitive Battery**: 9 interactive mini-games measuring reaction time, executive function, working memory, risk tolerance, and spatial reasoning.
3. **Strict Zero-Repeat Engine**: Cryptographic question hashes and per-student attempt tracking ensuring questions are never repeated in test attempts.
4. **Universal AI Proctoring**: Face tracking, gaze direction, audio levels, tab-switching deterrence, 3-strike dismissal protocol, and server-side immutable audit trails.

---

## 📦 What Is Included

### 1. Backend Modules (`server/`)
- `server/app/routes/aptitude.py`:
  - `GET /api/aptitude/overview`: Returns question counts, student mastery, and completion percentages for 9 categories.
  - `GET /api/aptitude/practice/questions`: Practice questions with step-by-step explanations.
  - `POST /api/aptitude/practice/submit`: Instant answer evaluation and explanation feedback.
  - `POST /api/aptitude/test/start`: Starts timed 20-minute test attempt with strict non-repeat filtering and mode locking (`NORMAL` or `PROCTORED`).
  - `GET /api/aptitude/attempts/active`: Resumes interrupted test attempts seamlessly.
  - `POST /api/aptitude/test/submit`: Computes server-side composite score (`Accuracy: 70%`, `Difficulty: 20%`, `Time: 10%`).
  - `POST /api/aptitude/gamified/battery/submit`: Normalizes raw mini-game telemetry into 9 standardized 0-100 cognitive dimension metrics.
  - `POST /api/aptitude/ai/generate-batch`: AI question generation with SHA-256 deduplication.
  - `POST /api/aptitude/proctor/event`: Authoritative proctor violation logging and 3-strike termination.
- `server/app/services/aptitude_service.py`:
  - Core in-memory question bank (450+ questions).
  - Attempt timer management, strike tracker, and dismissal state.
  - Cognitive dimension normalization algorithms.
- `server/app/data/aptitude_bank_seed.py`:
  - 450+ seed questions categorized into 9 distinct categories (Numerical, Verbal, Quantitative, Abstract, Spatial, Deductive, Mechanical, Data Sufficiency, Error Checking).
- `server/app/data/aptitude_data.py`:
  - Foundation aptitude problems with step-by-step derivations.
- `server/tests/test_aptitude_system.py`:
  - 8 automated test suites verifying question bank size, strict no-repeat rule, composite scoring, gamified battery normalization, SHA-256 deduplication, and mode locking.

### 2. Frontend Modules (`client/`)
- `client/src/views/AptitudeArenaView.tsx`:
  - Main unified interface supporting Normal Practice, Normal Test, Gamified Practice, and Gamified Battery.
  - Universal proctoring pre-check modal (Camera, Face Detection, Microphone).
  - Live proctor HUD with warning modals (Warning 1, Final Warning 2, Dismissal 3).
  - Instant results screen with radar / bar cognitive dimension breakdown.
- `client/src/components/aptitude/games/` (9 Interactive Games):
  - `RiskRewardGame.tsx` (Balloon Analog Risk Task - BART: evaluates risk vs reward calibration)
  - `WorkingMemoryGame.tsx` (N-Back sequence memory)
  - `CognitiveFlexibilityGame.tsx` (Dynamic rule-switching challenge)
  - `DynamicSpatialGame.tsx` (2D/3D mental orientation and rotation)
  - `PlanningStrategyGame.tsx` (Minimum-moves goal planning)
  - `InformationProcessingGame.tsx` (Rapid stimulus discrimination)
  - `ResourceManagementGame.tsx` (Constraint optimization & allocation)
  - `EmotionRecognitionGame.tsx` (Social intelligence & micro-expression detection)
  - `MazePressureGame.tsx` (Spatial navigation under time decay pressure)
- `client/src/services/proctoringEngine.ts`:
  - Re-exports the complete browser-based proctoring and violation detection engine.

---

## 🚀 Quick Installation

To install this module on another machine or project:
1. Extract `HireX_Aptitude_Arena_Module.zip` into your project root.
2. Run the automated installer:
   ```bash
   python apply_aptitude_patch.py
   ```
3. Run the test suite:
   ```bash
   python -m pytest server/tests/test_aptitude_system.py
   ```

---

## 🎮 9 Standardized Cognitive Dimensions

| Dimension | Mini-Game | Metric Measured |
| :--- | :--- | :--- |
| **Risk Tolerance** | Balloon Risk/Reward | Pumping threshold before pop vs. banked points |
| **Working Memory** | N-Back Flash | Sequence recall accuracy under latency |
| **Cognitive Flexibility** | Rule Switcher | Task-switching speed penalty (switch-cost ms) |
| **Spatial Visualization** | Mental Rotation | 3D angular match accuracy |
| **Strategic Planning** | Sequence Planner | Extra moves taken above optimal solution |
| **Processing Speed** | Stimulus Blitz | Accurate reactions per second |
| **Resource Allocation** | Capacity Manager | System stability & final resource margin |
| **Social Cognition** | Emotion Reader | Micro-expression recognition accuracy |
| **Resilience Under Pressure** | Countdown Maze | Error rate under active timer decay |
