#!/usr/bin/env python3
"""
HireX AI Mock Interview Simulator Intelligent Drop-in Installer.
Installs and integrates the AI Mock Interview Simulator into any target HireX installation:
- Automatically detects project root directory.
- Copies all backend services, routes, test suites, and frontend components.
- Integrates the router in server/app/main.py if not already present.
- Executes the test suite to verify 100% test integrity.
"""

import os
import sys
import shutil
import subprocess
import re

def log(msg):
    print(f"[HireX Interview Installer] {msg}")

def find_project_root():
    cwd = os.path.abspath(os.getcwd())
    if os.path.exists(os.path.join(cwd, "server")) and os.path.exists(os.path.join(cwd, "client")):
        return cwd
    script_dir = os.path.abspath(os.path.dirname(__file__))
    if os.path.exists(os.path.join(script_dir, "server")) and os.path.exists(os.path.join(script_dir, "client")):
        return script_dir
    parent = os.path.dirname(script_dir)
    if os.path.exists(os.path.join(parent, "server")) and os.path.exists(os.path.join(parent, "client")):
        return parent
    return None

def main():
    root_dir = find_project_root()
    if not root_dir:
        print("[ERROR] Could not locate HireX project root directory (containing 'server' and 'client').")
        sys.exit(1)

    log(f"Target HireX root: {root_dir}")
    source_dir = os.path.abspath(os.path.dirname(__file__))

    # 1. Copy Files
    for root, dirs, files in os.walk(source_dir):
        for f in files:
            if f in ["apply_interview_patch.py", "README_AI_MOCK_INTERVIEW.md"]:
                continue
            src_full = os.path.join(root, f)
            rel = os.path.relpath(src_full, source_dir)
            dst_full = os.path.join(root_dir, rel)
            os.makedirs(os.path.dirname(dst_full), exist_ok=True)
            shutil.copy2(src_full, dst_full)
            log(f"Installed: {rel}")

    # 2. Patch server/app/main.py if router not included
    main_py = os.path.join(root_dir, "server", "app", "main.py")
    if os.path.exists(main_py):
        with open(main_py, "r", encoding="utf-8") as f:
            content = f.read()
        if "interview" not in content:
            if "from app.routes import" in content:
                content = re.sub(r"from app\.routes import ([^\n]+)", r"from app.routes import \1, interview", content, count=1)
            if "app.include_router(interview.router)" not in content:
                content = content.replace("app.include_router(", "app.include_router(interview.router)\napp.include_router(", 1)
            with open(main_py, "w", encoding="utf-8") as f:
                f.write(content)
            log("Patched server/app/main.py with interview.router")
        else:
            log("server/app/main.py already configured with interview router.")

    # 3. Run validation tests
    log("Running automated validation test suite...")
    env = os.environ.copy()
    env["PYTHONPATH"] = os.path.join(root_dir, "server")
    try:
        res = subprocess.run(
            [sys.executable, "-m", "unittest", "tests/test_interview_system.py"],
            cwd=os.path.join(root_dir, "server"),
            env=env,
            capture_output=True,
            text=True
        )
        if res.returncode == 0:
            log("SUCCESS! All Interview System test cases PASSED!")
        else:
            log(f"Unittest output:\n{res.stdout}\n{res.stderr}")
    except Exception as e:
        log(f"Note: Could not automatically invoke unittest: {e}")

    log("AI Mock Interview Simulator installation complete!")

if __name__ == "__main__":
    main()
