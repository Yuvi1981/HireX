# 🎙️ HireX: AI Mock Interview Simulator Subsystem

The **AI Mock Interview Simulator** is a full-lifecycle corporate interview simulator integrated into the institutional AICTE portal, replicating real-world technical and HR rounds with adaptive questioning, speech input/output, and audit reports.

---

## 🌟 Key Features

### 1. Multi-Dimensional Interview Setup (`InterviewSetupCard.tsx`)
- **Configurable Roles**: Software Developer, Frontend, Backend, Full Stack, Data Analyst / Scientist, DevOps, Mobile Engineer.
- **Interview Rounds**: HR & Behavioral, Technical Fundamentals, DSA & Problem Solving, System Design & Architecture, Project & Resume Discussion.
- **Difficulty & Duration**: Beginner, Intermediate, Advanced | 10, 15, or 30 minutes.
- **Target Company Alignment**: Barclays, Google, Amazon, Microsoft, TCS, Infosys, etc.
- **Context Injection**: Optional Job Description (JD) text and Resume snippets for hyper-personalized questions.

### 2. Conversational Interview Room (`InterviewRoomView.tsx`)
- **Speech Recognition (Voice Input)**: Web Speech API microphone integration with real-time speech-to-text.
- **Speech Synthesis (Voice Output)**: Natural voice text-to-speech reading interviewer questions aloud.
- **Adaptive Follow-up Questions**: Dynamically evaluates the candidate's response and generates context-aware follow-up challenges.
- **Live Interview Timer**: Auto-submits upon time expiry with countdown HUD.
- **Previous Evaluation Peek**: Instant micro-feedback with keywords detected, technical accuracy, and improvement hints.

### 3. Institutional Performance Report (`InterviewResultDashboard.tsx`)
- **Harmonized UI Color Grading**: High-contrast, theme-consistent color styling (Emerald ready, Blue proficient, Amber borderline, Rose needs work).
- **Competency Scorecard**: Technical Accuracy, Communication Clarity, Problem Solving, and Topic Relevance (0-10 scale).
- **Personalized Growth Plan**: Tailored recommended actions, documentation references, and practice areas.
- **Question-by-Question Deep Dive**: Detailed breakdown with candidate response, ideal sample answer, and evaluator feedback.

### 4. Historical Tracking (`InterviewHistoryList.tsx` & `canonical_store.json`)
- Per-student historical session archive with past scores, completion dates, and retake buttons.

---

## 📦 What Is Included

### Backend (`server/`)
- `server/app/routes/interview.py`: REST API endpoints:
  - `GET /api/interview/config`: Provider status and role/round taxonomy.
  - `POST /api/interview/start`: Session initialization with tailored first question.
  - `POST /api/interview/submit-answer`: Evaluates response and generates adaptive next question.
  - `POST /api/interview/complete`: Final report generation with dimension scores and recommendations.
  - `GET /api/interview/history/{student_id}`: Candidate session history retrieval.
- `server/app/services/interview_service.py`: Question generation engine, evaluation heuristics, Gemini/Groq LLM connector with offline knowledge-graph fallback.
- `server/tests/test_interview_system.py`: Automated tests verifying session creation, answer evaluation, score computation, and authorization boundaries.

### Frontend (`client/`)
- `client/src/views/InterviewSimulatorView.tsx`: Main view with mode switching (SETUP, ROOM, REPORT, HISTORY).
- `client/src/components/interview/InterviewSetupCard.tsx`: Configuration screen with role cards and JD upload.
- `client/src/components/interview/InterviewRoomView.tsx`: Audio-enabled interview interface with speech input and timer.
- `client/src/components/interview/InterviewResultDashboard.tsx`: Color-graded comprehensive evaluation report.
- `client/src/components/interview/InterviewHistoryList.tsx`: Historical session cards with score badges.
- `client/src/types/interview.ts`: TypeScript interfaces for configs, questions, evaluations, and reports.

---

## 🚀 Quick Installation
1. Extract `ai_mock_interview.zip` into your project root.
2. Run the automated installer:
   ```bash
   python apply_interview_patch.py
   ```
3. Run the automated test suite:
   ```bash
   python -m unittest server/tests/test_interview_system.py
   ```
